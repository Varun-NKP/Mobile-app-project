package com.app.checkstocks.constants;

public class Constants {

    public static final String NASDAQ_API_KEY = ""; //Not required
}
